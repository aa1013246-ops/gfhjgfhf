// Service Worker for Al-Umam Recruitment Office
// Progressive Web App functionality

const CACHE_NAME = 'samma-sa-v1.0.0';
const urlsToCache = [
    '/',
    '/index.html',
    '/privacy.html',
    '/terms.html',
    '/manifest.json',
    '/humans.txt',
    'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&family=Amiri:wght@400;700&display=swap',
    'https://fonts.gstatic.com/s/cairo/v28/SLXgc1nY6HkvalIhTp2mxdt0UX8.woff2',
    'https://fonts.gstatic.com/s/amiri/v28/J7aFnoNzCdQxyag2i6OV7CgNdOAb.woff2'
];

// Install event - cache resources
self.addEventListener('install', function(event) {
    console.log('[Service Worker] Installing...');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                console.log('[Service Worker] Caching app shell');
                return cache.addAll(urlsToCache);
            })
            .then(function() {
                console.log('[Service Worker] Install completed');
                return self.skipWaiting();
            })
            .catch(function(error) {
                console.log('[Service Worker] Install failed:', error);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', function(event) {
    console.log('[Service Worker] Activating...');
    
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName !== CACHE_NAME) {
                        console.log('[Service Worker] Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(function() {
            console.log('[Service Worker] Activation completed');
            return self.clients.claim();
        })
    );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', function(event) {
    // Skip cross-origin requests
    if (!event.request.url.startsWith(self.location.origin)) {
        return;
    }
    
    // Skip POST requests and other non-GET requests
    if (event.request.method !== 'GET') {
        return;
    }
    
    event.respondWith(
        caches.match(event.request)
            .then(function(response) {
                // Return cached version or fetch from network
                if (response) {
                    console.log('[Service Worker] Serving from cache:', event.request.url);
                    return response;
                }
                
                console.log('[Service Worker] Fetching from network:', event.request.url);
                return fetch(event.request).then(function(response) {
                    // Don't cache if not a valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }
                    
                    // Clone the response
                    const responseToCache = response.clone();
                    
                    // Cache the fetched response
                    caches.open(CACHE_NAME)
                        .then(function(cache) {
                            cache.put(event.request, responseToCache);
                        });
                    
                    return response;
                }).catch(function(error) {
                    console.log('[Service Worker] Fetch failed:', error);
                    
                    // Return offline page for HTML requests
                    if (event.request.headers.get('Accept').includes('text/html')) {
                        return caches.match('/offline.html');
                    }
                    
                    // Return error for other requests
                    throw error;
                });
            })
    );
});

// Background sync
self.addEventListener('sync', function(event) {
    console.log('[Service Worker] Background sync:', event.tag);
    
    if (event.tag === 'contact-form') {
        event.waitUntil(sendContactForm());
    }
});

// Push notifications
self.addEventListener('push', function(event) {
    console.log('[Service Worker] Push received');
    
    const options = {
        body: event.data ? event.data.text() : 'رسالة جديدة من مكتب الأمم للاستقدام',
        icon: '/assets/icon-192x192.png',
        badge: '/assets/badge-72x72.png',
        dir: 'rtl',
        lang: 'ar',
        tag: 'samma-notification',
        requireInteraction: true,
        actions: [
            {
                action: 'view',
                title: 'عرض',
                icon: '/assets/action-view.png'
            },
            {
                action: 'close',
                title: 'إغلاق',
                icon: '/assets/action-close.png'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification('مكتب الأمم للاستقدام', options)
    );
});

// Notification click
self.addEventListener('notificationclick', function(event) {
    console.log('[Service Worker] Notification clicked');
    
    event.notification.close();
    
    if (event.action === 'view') {
        event.waitUntil(
            clients.openWindow('https://samma-sa.com')
        );
    }
});

// Message from main thread
self.addEventListener('message', function(event) {
    console.log('[Service Worker] Message received:', event.data);
    
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});

// Helper functions
function sendContactForm() {
    // Implement contact form submission logic
    return Promise.resolve();
}

// Update cache periodically
function updateCache() {
    console.log('[Service Worker] Updating cache...');
    
    return caches.open(CACHE_NAME)
        .then(function(cache) {
            return cache.addAll(urlsToCache);
        })
        .then(function() {
            console.log('[Service Worker] Cache updated');
        })
        .catch(function(error) {
            console.log('[Service Worker] Cache update failed:', error);
        });
}

// Periodic background sync
setInterval(updateCache, 24 * 60 * 60 * 1000); // Update every 24 hours